var DBconfigs = {
    clouddb: {
        dbname : "AtnShop",
        dbusername : "lockq2k",
        dbpassword : "kieuquangloc123",
    }

};

module.exports = DBconfigs.clouddb;